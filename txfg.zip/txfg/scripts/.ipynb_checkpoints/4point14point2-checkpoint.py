import torch.nn.functional as F
import argparse
import os
from ssl import OP_NO_TLSv1
import nibabel as nib
# from visdom import Visdom
# viz = Visdom(port=8850)
import sys
import random
sys.path.append(".")
import numpy as np
import time
import torch as th
import torch.distributed as dist
from guided_diffusion import dist_util, logger
from guided_diffusion.bratsloader import BRATSDataset, BRATSDataset3D
from guided_diffusion.isicloader import ISICDataset3
from guided_diffusion.custom_dataset_loader import CustomDataset
import torchvision.utils as vutils
from guided_diffusion.utils import staple
from guided_diffusion.script_util import (
    NUM_CLASSES,
    model_and_diffusion_defaults,
    create_model_and_diffusion,
    add_dict_to_argparser,
    args_to_dict,
)
import torchvision.transforms as transforms
from torchsummary import summary
import torch
from torch.autograd import Function
import torchvision
seed=10
th.manual_seed(seed)
th.cuda.manual_seed_all(seed)
np.random.seed(seed)
random.seed(seed)

def visualize(img):
    _min = img.min()
    _max = img.max()
    normalized_img = (img - _min)/ (_max - _min)
    return normalized_img


def main():
    args = create_argparser().parse_args()
    dist_util.setup_dist(args)
    logger.configure(dir = args.out_dir)

    if args.data_name == 'ISIC':
        tran_list = [transforms.Resize((args.image_size,args.image_size)), transforms.ToTensor(),]
        transform_test = transforms.Compose(tran_list)

        ds = ISICDataset3(args.data_dir, transform_test)
        args.in_ch = 4
    elif args.data_name == 'BRATS':
        tran_list = [transforms.Resize((args.image_size,args.image_size)),]
        transform_test = transforms.Compose(tran_list)

        ds = BRATSDataset3D(args.data_dir,transform_test)
        args.in_ch = 5
    else:
        tran_list = [transforms.Resize((args.image_size, args.image_size)), transforms.ToTensor()]
        transform_test = transforms.Compose(tran_list)

        ds = CustomDataset(args, args.data_dir, transform_test, mode = 'Test')
        args.in_ch = 4

    datal = th.utils.data.DataLoader(
        ds,
        batch_size=args.batch_size,
        shuffle=False)
    data = iter(datal)

    logger.log("creating model and diffusion...")

    model, diffusion = create_model_and_diffusion(
        **args_to_dict(args, model_and_diffusion_defaults().keys())
    )
    all_images = []


    state_dict = dist_util.load_state_dict(args.model_path, map_location="cpu")
    from collections import OrderedDict
    new_state_dict = OrderedDict()
    for k, v in state_dict.items():
        # name = k[7:] # remove `module.`
        if 'module.' in k:
            new_state_dict[k[7:]] = v
            # load params
        else:
            new_state_dict = state_dict

    model.load_state_dict(new_state_dict)

    model.to(dist_util.dev())
    if args.use_fp16:
        model.convert_to_fp16()
    model.eval()
    os.makedirs(args.out_dir, exist_ok=True)
    adv_dir = os.path.join(args.out_dir, "adv_images")
    os.makedirs(adv_dir, exist_ok=True)
    output_dir = os.path.join(args.out_dir, "adv_output")
    os.makedirs(output_dir, exist_ok=True)
    mean_list = []
    for _ in range(len(data)):
        b,path = next(data)  #should return an image from the dataloader "data"
        b_adv = b.clone().detach().to(b.device)
        b_adv.requires_grad = True
        c = th.randn_like(b[:, :1, ...])
        slice_ID=path[0].split("_")[-1].split('.')[0]
        logger.log("sampling...")
        epsilon = 8 / 255
        alpha = 1 / 255
        start = th.cuda.Event(enable_timing=True)
        end = th.cuda.Event(enable_timing=True)
        start.record()
        for i in range(20):
            
            img = th.cat((b_adv, c), dim=1)     #add a noise channel$
            model_kwargs = {}
            sample_fn = diffusion.p_sample_loop_known1
            sample, x_noisy, org, cal, cal_out, grad = sample_fn(
                model,
                (args.batch_size, 3, args.image_size, args.image_size), img, b_adv,
                step = args.diffusion_steps,
                clip_denoised=args.clip_denoised,
                model_kwargs=model_kwargs,
            )
            grad = grad.to(b_adv.device)
            b_adv = b_adv + alpha * torch.sign(grad)
            b_adv = torch.clamp(b_adv, b - epsilon, b + epsilon)
            b_adv = torch.clamp(b_adv, 0, 1).detach()
            b_adv.requires_grad = True
        print(sample[:,-1,:,:].mean())
        mean_list.append(sample[:,-1,:,:].mean().item())
        end.record()
        th.cuda.synchronize()
        logger.log(f"Time for sampling:{start.elapsed_time(end)} ms")
        vutils.save_image(b_adv, fp=os.path.join(args.out_dir,"adv_images",str(slice_ID) + '_adversarial' + ".png"), nrow=1, padding=0)
        img = th.cat((b_adv, c), dim=1)
        
        sample, x_noisy, org, cal, cal_out,grad = diffusion.p_sample_loop_known(
            model,
            (args.batch_size, 3, args.image_size, args.image_size), img,b_adv,
            step=args.diffusion_steps,
            clip_denoised=args.clip_denoised,
            model_kwargs=model_kwargs,
        )
        
        
        vutils.save_image(sample[:,-1:,...], fp=os.path.join(args.out_dir,"adv_output", str(slice_ID) + '_output_ens' + ".png"), nrow=1,padding=0)

        




def create_argparser():
    defaults = dict(
        data_name = 'BRATS',
        data_dir="../dataset/brats2020/testing",
        clip_denoised=True,
        num_samples=1,
        batch_size=1,
        use_ddim=False,
        model_path="",         #path to pretrain model
        num_ensemble=5,      #number of samples in the ensemble
        gpu_dev = "0",
        out_dir='./results/',
        multi_gpu = None, #"0,1,2"
        debug = False
    )
    defaults.update(model_and_diffusion_defaults())
    parser = argparse.ArgumentParser()
    add_dict_to_argparser(parser, defaults)
    return parser


if __name__ == "__main__":

    main()
