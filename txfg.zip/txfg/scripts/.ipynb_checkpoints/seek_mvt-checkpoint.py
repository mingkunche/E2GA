import argparse
import os
import pandas as pd
import sys
import random
import numpy as np
import torch as th
sys.path.append(".")

from guided_diffusion import dist_util, logger
from guided_diffusion.bratsloader import BRATSDataset, BRATSDataset3D
from guided_diffusion.isicloader import ISICDataset2
import torchvision.utils as vutils
from guided_diffusion.script_util import (
    NUM_CLASSES,
    model_and_diffusion_defaults,
    create_model_and_diffusion,
    add_dict_to_argparser,
    args_to_dict,
)
from guided_diffusion.my import TrainLoop1,TrainLoop2,TrainLoop3,TrainLoop4
import torchvision.transforms as transforms
import torch
from torch.autograd import Function
import torchvision

seed = 10
th.manual_seed(seed)
th.cuda.manual_seed_all(seed)
np.random.seed(seed)
random.seed(seed)


def main():
    args = create_argparser().parse_args()
    dist_util.setup_dist(args)
    logger.configure(dir=args.out_dir)

    if args.data_name == 'ISIC':
        tran_list = [transforms.Resize((args.image_size, args.image_size)), transforms.ToTensor(), ]
        transform_test = transforms.Compose(tran_list)

        ds = ISICDataset2(args.data_dir, transform_test)
        args.in_ch = 4
    elif args.data_name == 'BRATS':
        tran_list = [transforms.Resize((args.image_size, args.image_size)), ]
        transform_test = transforms.Compose(tran_list)
        ds = BRATSDataset3D(args.data_dir, transform_test)
        args.in_ch = 5

    datal = th.utils.data.DataLoader(
        ds,
        batch_size=args.batch_size,
        shuffle=False)
    data = iter(datal)

    logger.log("creating model and diffusion...")

    model, diffusion = create_model_and_diffusion(
        **args_to_dict(args, model_and_diffusion_defaults().keys())
    )

    state_dict = dist_util.load_state_dict(args.model_path, map_location="cpu")
    from collections import OrderedDict
    new_state_dict = OrderedDict()
    for k, v in state_dict.items():
        # name = k[7:] # remove `module.`
        if 'module.' in k:
            new_state_dict[k[7:]] = v
            # load params
        else:
            new_state_dict = state_dict

    model.load_state_dict(new_state_dict)

    model.to(dist_util.dev())
    if args.use_fp16:
        model.convert_to_fp16()
    model.eval()
    for _ in range(len(data)):
        b, m, slice_ID = next(data)
        slice_ID = slice_ID[0]# should return an image from the dataloader "data"
        print(slice_ID)
        b.requires_grad = True
        #设置输入图像的requires_grad=True

        logger.log("sampling...")

        #记录时间
        start = th.cuda.Event(enable_timing=True)
        end = th.cuda.Event(enable_timing=True)
        start.record()

        grad = TrainLoop2(
            model=model,
            diffusion=diffusion,
            data =(b, m),
            target_step=800
        ).run_loop()

        end.record()
        th.cuda.synchronize()

        logger.log(f"Time for sampling: {start.elapsed_time(end)} ms")


        b = b - torch.sign(grad) * 8 / 255
        torch.save(b,"tensor2.pt")
        #vutils.save_image(b, fp=os.path.join(args.out_dir, slice_ID + '_adversarial' + ".jpg"), nrow=1, padding=10)
def create_argparser():
    defaults = dict(
        data_name='BRATS',
        data_dir="../dataset/brats2020/testing",
        clip_denoised=True,
        num_samples=1,
        batch_size=1,
        use_ddim=False,
        model_path="",  # path to pretrain model
        num_ensemble=5,  # number of samples in the ensemble
        gpu_dev="0",
        out_dir='./results/',
        multi_gpu=None,  # "0,1,2"
        debug=False
    )
    defaults.update(model_and_diffusion_defaults())
    parser = argparse.ArgumentParser()
    add_dict_to_argparser(parser, defaults)
    return parser


if __name__ == "__main__":

    main()
